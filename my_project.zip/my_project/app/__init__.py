# Initialize the app
