# app/model.py

def train_model():
    # Funkcja trenowania modelu
    print("Trenowanie modelu...")

def use_model(input_text):
    # Funkcja używania modelu do generowania odpowiedzi
    return "Odpowiedź na: " + input_text
