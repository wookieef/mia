class Config:
    DEBUG = True
    TESTING = False
    SECRET_KEY = 'super_secret_key'
    JWT_SECRET_KEY = 'super_jwt_secret_key' 
