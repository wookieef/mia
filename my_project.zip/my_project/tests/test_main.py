import unittest
from app.main import app

class MainTestCase(unittest.TestCase):

    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True

    def test_home(self):
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json, {"message": "Hello, world!"})

    def test_execute(self):
        response = self.app.post('/execute', json={"command": "echo Hello"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json, {"output": "Hello\n"})

if __name__ == '__main__':
    unittest.main()
