from flask import Blueprint, request, jsonify
import subprocess

main = Blueprint('main', __name__)

@main.route('/chat', methods=['POST'])
def chat():
    data = request.json
    message = data.get('message')
    response = f"I received your message: {message}"
    return jsonify({'response': response})

@main.route('/execute', methods=['POST'])
def execute():
    data = request.json
    command = data.get('command')
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    return jsonify({'output': result.stdout})
