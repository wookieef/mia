class Config:
    SECRET_KEY = 'supersecretkey'
