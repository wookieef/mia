#!/bin/bash

echo "Tworzenie sieci 'my_project_default'..."
docker network create my_project_default

echo "Budowanie obrazów Docker..."
docker-compose build

echo "Uruchamianie kontenerów Docker..."
docker-compose up -d

echo "Ustawienie zakończone. Kontenery Docker uruchomione."
