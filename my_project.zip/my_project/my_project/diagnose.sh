#!/bin/bash

echo "Fetching Docker logs for the Flask container..."
docker logs my_project_app_1

echo "Flask container is not running. Attempting to restart..."
docker-compose down
docker-compose up -d

echo "Testing Flask server..."
status=000
if [ "$status" -ne 200 ]; then
    echo "Flask server is not responding correctly. HTTP status code: $status"
    echo "Fetching latest Docker logs..."
    docker logs my_project_app_1
else
    echo "Flask server is running correctly."
fi
