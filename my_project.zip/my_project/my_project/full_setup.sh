#!/bin/bash

echo "### Krok 1: Przygotowanie środowiska ###"
sudo apt-get update
sudo apt-get install -y python3 python3-pip docker-ce docker-ce-cli containerd.io docker-compose-plugin

echo "### Krok 2: Klonowanie repozytorium ###"
git clone https://github.com/user/my_project.git
cd my_project

echo "### Krok 3: Budowanie i uruchamianie kontenerów ###"
docker-compose down
docker-compose up --build -d

echo "### Krok 4: Testowanie serwera Flask ###"
sleep 10  # Czekaj na uruchomienie kontenerów
curl -X POST http://localhost:5000/chat -H "Content-Type: application/json" -d '{"message":"Hello"}'

echo "### Krok 5: Diagnozowanie problemów ###"
./diagnose.sh
