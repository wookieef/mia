import unittest
from app import create_app

class MainTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.client = self.app.test_client()

    def test_chat_endpoint(self):
        response = self.client.post('/chat', json={'message': 'Hello'})
        data = response.get_json()
        self.assertEqual(response.status_code, 200)
        self.assertIn('I received your message: Hello', data['response'])

    def test_execute_endpoint(self):
        response = self.client.post('/execute', json={'command': 'echo Hello'})
        data = response.get_json()
        self.assertEqual(response.status_code, 200)
        self.assertIn('Hello', data['output'])

if __name__ == '__main__':
    unittest.main()
